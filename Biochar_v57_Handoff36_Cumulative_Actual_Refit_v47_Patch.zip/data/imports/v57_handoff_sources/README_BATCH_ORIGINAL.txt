BIOCHAR ML — KIRO HANDOFF (CURRENT DATA BATCH)

[01_APPROVED_DATA]
- Kiro_approved_experimental_qe_rows.csv
  -> Kiro에 우선 반영할 experimental qe 승인 행.
  -> fitted Langmuir qmax는 포함하지 않음.
  -> Figure에서 추출한 값은 digitized=TRUE로 구분.
- Biochar_Kiro_Experimental_qe_QC.xlsx
  -> Approved_Rows / Paper_QC / Excluded_QC / README 포함.

현재 1차 승인: 36행
- Shen et al. 2017, Ni: 29행 (Figure 6 experimental markers; 물질수지 QC 통과 행만)
- Cao et al. 2019, Pb: 7행 (Table 2 직접 보고값)

[02_SOURCE_PAPERS]
1. Shen 2017 / Wheat straw pellets + rice husk / Ni
   DOI 10.1007/s11356-017-8847-2
   - Experimental isotherm points 사용 가능
   - Table 2 Langmuir Qmax는 target qe로 사용 금지
   - TPV 미보고

2. Alam 2018 / Ni + Zn
   DOI 10.1021/acs.est.7b06261
   - Main + Supplement 포함
   - BET + pore volume 제공
   - pH-dependent experimental adsorption points 존재
   - 17 uM Zn의 WPC 및 SSBC300은 Zn leaching 영향 때문에 제외 권장
   - 다음 digitization/QC 우선 후보

3. Sun 2014 / Five feedstocks / Cd
   DOI 10.1016/j.ecoenv.2014.04.042
   - BET + total pore volume 제공
   - Figure 1 experimental isotherm 존재
   - 현재 그래프-C0 재구성 QC 이슈로 자동 학습 투입하지 않고 재검토 필요

4. Zhao 2020 / Rice straw + chicken manure + sewage sludge / Pb, Zn
   DOI 10.1016/j.scitotenv.2020.136894
   - Main + Supplement 포함
   - BET SSA + pore volume 제공
   - Figure 3 experimental isotherm points 사용 후보
   - Table 3 Langmuir qmax는 target qe로 사용 금지
   - 다음 digitization/QC 우선 후보

5. Cao 2019 / Wheat straw / Pb / 300–900 C
   DOI 10.1016/j.scitotenv.2019.07.102
   - 7개 제조온도의 experimental qTotal 직접 표 제공
   - 7행 승인 파일에 포함됨
   - BET/TPV full-link용보다는 Stage2/temperature-ranking 보강용

[03_HOLD_SOURCE]
- Uchimiya 2010 / Broiler litter / Cu, Cd, Ni, Pb
  DOI 10.1021/jf9044217
  - 현재 Supporting Information만 확보
  - main article 없이 experimental qe + C0/dose 연결을 확정하기 부족하므로 HOLD

IMPORTANT
- fitted qmax를 experimental qe로 사용하지 말 것.
- digitized experimental point와 표 직접값을 source_value_type으로 반드시 구분할 것.
- 물질수지 qe <= C0/dose 조건을 확인할 것.
- 동일 DOI/Material이 train/test 양쪽에 누출되지 않도록 group split할 것.
