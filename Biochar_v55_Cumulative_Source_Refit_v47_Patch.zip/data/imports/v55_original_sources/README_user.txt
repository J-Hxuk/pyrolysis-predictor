Stage 1→2 연결 관측치 보완용 신규 논문 5편

[PRIORITY]
1) Cocoa pod hull / Cd
   DOI: 10.1007/s13399-026-07198-4
   강점: 400/650/900°C, BET + total pore volume + experimental adsorption data

2) Ragweed + Horseweed / Cd + Pb
   DOI: 10.1016/j.biortech.2020.124011
   강점: 2 feedstocks × 3 temperatures, BET + total pore volume, adsorption data
   주의: fitted qe와 experimental endpoint 구분 필요

[CONDITIONAL]
3) Rice straw + digested rice straw / Pb
   DOI: 10.1155/2018/2684962
   강점: multi-temperature + BET + Pb adsorption
   제한: TPV 직접값 부족

4) Sugarcane bagasse / Pb
   DOI: 10.1016/j.chemosphere.2013.12.042
   강점: 250/400/500/600°C + BET + Pb adsorption
   제한: TPV 없음, qmax 중심

5) Municipal wastewater sludge / Pb + Cr
   DOI: 10.1016/j.biortech.2013.08.082
   강점: 300-600°C × 1/2 h + BET + adsorption
   제한: 모든 조건의 TPV 직접값이 깔끔하지 않음
