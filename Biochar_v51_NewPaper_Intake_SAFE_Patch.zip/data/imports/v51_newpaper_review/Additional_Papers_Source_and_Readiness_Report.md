# 추가 문헌 3편 원문 점검 부록

작성일: 2026-10-31
기준: vNext10 DOI 노출·학습 후보 자료 및 공개 원문/서지 기록. 기존 승인 데이터와 모델 파일은 변경하지 않았다.

## 요약

| DOI | 확인된 내용 | 데이터 판정 | 독립성 |
|---|---|---|---|
| 10.3390/toxics10120787 | 대나무 4 제조온도, Cu qe 4개 직접 본문 보고, Cd figure 근사 4개 및 본문과 불일치. 표 4 물성은 BC500과 개질재만. | 모든 관측 REVIEW. strict qe 미승인. dose/접촉시간·평형 근거와 3개 온도별 BET/TPV 미확인. | 프로젝트 노출표에 DOI 미발견. 외부 holdout 인증은 보류. |
| 10.1016/j.biortech.2013.03.186 | Miscanthus 300–600°C, abstract maximum capacity 13.24 mg/g. | 시료별 관측·물성 추출 불가. | 활성 Stage1 BET 학습 후보에 DOI가 있어 historically exposed. 외부 holdout 금지. |
| 10.2166/wst.2020.309 | spent tea 4온도 × 2시간. abstract maximum capacity 97.415 mg/g. | 최대 capacity를 strict qe로 쓰지 않음. 본문 표/조건 미확보. | 체크한 vNext10 노출 파일에 DOI 없음. 보류 후보일 뿐 holdout 미인증. |

## 대나무 논문: 추출 및 판정

원문 §2.2는 Moso bamboo를 세척·건조(80°C), 100 mesh로 분쇄한 뒤 100 g을 quartz tube에 넣어 400/500/600/700°C에서 10°C/min으로 승온, 60분 유지 후 냉각했다고 기술한다. 제조 시료명은 BC400/500/600/700이다. 분위기와 가스 유량은 현재 확인한 본문에서 미보고이므로 NR이다.

§3.1/Figure 1은 각 금속 실험에서 C0=50 mg/L, pH=6, 용액 120 mL, 주변온도 25°C를 기재한다. 본문은 Cu q 값 네 개를 1.79, 2.48, 2.53, 2.56 mg/g로 직접 나열한다. 같은 문단은 Cd 값을 세 개(2.89, 3.96, 4.01 mg/g)만 네 시료에 대응시켜 보고한다. Figure 1의 텍스트 렌더에는 네 개 대략값(2.88, 3.96, 4.00, 4.11)이 나오지만 원본 그림을 확대 판독해 독립 재현한 수치가 아니고 본문과 차이가 있어 후보 열에만 남겼다. Cd 값은 확정 매핑하지 않았다.

원문 Table 4의 BET/기공 표는 BC500 4.2422 m²/g, BJH total pore capacity 0.000693 cm³/g를 보고한다. 나머지는 KBC500-2, KAM500-400-3, HBC500-30 개질재이며 BC400/600/700 값이 아니다. 따라서 개질재 수치를 제조온도 시료에 붙이지 않았다. BC500도 ‘BJH total pore capacity’라는 원문 정의를 그대로 보존한다.

현재 확인된 Figure 1 본문에는 흡착제 dose, 실험 contact time, 해당 무개질 BC 시료의 평형 도달 근거 또는 Ce가 없다. KAM500-400-3의 kinetics 결과(다른 개질 시료)는 이 비교군으로 옮겨 쓰지 않는다. 따라서 8개 q 관측은 원문 보고값/figure 근사 후보이며 strict qe와 순위 검증 계열로 승인하지 않았다. 물질수지 검산에도 dose/Ce가 필요하다.

## 시료별 Stage 판정

- Stage 1: 표 4의 직접 물성은 BC500 1개 시료뿐이다. 열분해 온도·시간·승온속도는 확인되나 분위기, 원료 조성은 NR이다. Stage 1 v60 계약의 입력 완전성을 충족했다고 볼 수 없어 training-ready 승인 없음.
- Stage 2: C0, pH, 온도는 본문에서 확인된다. dose와 qe에 대응한 contact/equilibrium time이 빠져 있고, BET/TPV는 BC500 이외 제조시료에 연결되지 않아 feature-complete 아님. strict-qe 승인 0행.
- 전체 경로: 0개.
- 제조조건 순위: Cu와 Cd 모두 네 온도 후보는 있으나 동일 조건·실측 평형 qe·투입량 근거가 닫히지 않아 0계열 승인. 내부 REVIEW 후보로 보존.

## DOI 노출 감사

vNext10의 DOI Exposure CSV에서 Miscanthus DOI는 HISTORICALLY_EXPOSED로 분류되어 있으며 Stage1 BET training candidate 파일에도 동일 DOI 기록이 있다. 해당 기록은 active Stage1 학습 노출을 뜻하므로 외부 독립검증에 사용하지 않는다. 대나무·spent tea DOI는 검사한 vNext10 Stage1/Stage2 exposure registries에 DOI 일치행이 없었다. 이는 검토 가능한 파일에서의 미발견 결과이며 전체 원시 개발이력/동일 시료 중복까지 부재한다는 증명은 아니다. 두 DOI 모두 잠금된 외부 holdout으로 등록하지 않았다.

## 다음 확보 항목

1. Bamboo 공식 SI (toxics10120787-s1)에서 BC400/600/700 BET·TPV, Figure 1 adsorption dose, sampling/contact time, qe 계산식/평형 조건을 확인한다. Cd 본문-그림 불일치는 원본 그래프 및 SI로 해결한다.
2. Miscanthus 출판사 PDF 또는 저자/기관 저장소 원문을 확보한다. 학습에 이미 노출된 DOI이므로 용도는 기존 데이터 복구·재감사로 한정한다.
3. Spent tea publisher PDF/SI에서 sample별 물성표, adsorption procedure, 실측 qe/C0/Ce/pH/dose/time/temperature를 확보한다. Langmuir Qmax와 직접 실험값을 분리한다.
4. 원문/시료 중복과 Stage1·Stage2 exposure를 project-wide registry로 다시 확인한 뒤에만 spent tea를 외부 holdout으로 판정한다.

## 출처

- Bamboo primary PDF: https://www.mdpi.com/2305-6304/10/12/787/pdf?version=1671610413 (특히 §2.2, §3.1/Figure 1, Table 4, Supplementary Materials 안내)
- Bamboo publisher/PMC record: https://pmc.ncbi.nlm.nih.gov/articles/PMC9784441/
- Miscanthus PubMed abstract: https://pubmed.ncbi.nlm.nih.gov/23619139/
- Miscanthus publisher abstract page: https://www.sciencedirect.com/science/article/abs/pii/S0960852413005907
- Spent tea PubMed abstract: https://pubmed.ncbi.nlm.nih.gov/32857741/
- Spent tea IWA page: https://iwaponline.com/wst/article-abstract/81/12/2533/75170/Effect-of-temperature-and-duration-of-pyrolysis-on
