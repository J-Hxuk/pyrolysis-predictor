# 신규 후보 6개 DOI 원문 선별 및 관측 추출 결과

작성일: 2026-10-31
기준: 사용자가 제공한 우선순위 이미지, 작업공간의 최신 프로젝트 ZIP 및 과거 검증자료. 기존 모델·UI·승인 데이터는 수정하지 않았습니다.

## 결론

- 화면의 두 번째 DOI는 `10.3390/jms21165851`로 적혀 있으나, 해당 논문 DOI는 `10.3390/ijms21165851`입니다. 정정 DOI의 논문은 sunflower husks, sunflower husks+rapeseed pomace, wood waste 세 원료를 300/400/500°C에서 처리한 연구입니다.
- 6편에서 새로 추가·승인한 데이터 행은 **0행**입니다. 다만 차나무 가지 논문에서는 **기존 REVIEW 관측 5건**의 실측 평형 qe 근거를 확인하여 기존 행에 대한 승격 검토 근거를 정리했습니다. 이 5건은 새 데이터로 중복 추가하지 않았습니다.
- 신규 strict-qe source verification: 1 DOI / 5개 관측값(기존 행 재검토). 신규 Stage 1 적격 소재, 신규 Stage 2 학습 적격 관측, 독립 외부 holdout은 모두 0입니다.
- 제조조건 순위 비교 자료로는 차나무 가지의 Cd 5온도 계열이 동일 흡착조건에서 비교 가능하지만, 이미 Stage 1 학습 코어에 노출된 DOI이므로 내부 개발용 시리즈입니다. 독립 외부 검증은 아닙니다.

## 논문별 판정

| DOI | 원문 확인 결과 | Strict qe | BET/TPV | 평가 판정 |
|---|---|---:|---|---|
| 10.1039/D1RA04235A | 본문 Table 2의 `Qe^a`가 실제 흡착용량이라고 각주에 명시. 동역학 실험에서 약 4시간 후 평형, 배치 실험은 24시간. | 5 기존 관측 승인 근거 확인 | BET 5개 확인. 표의 generic pore volume은 total인지 확인되지 않아 TPV=NR | 내부 조건순위 series 가능; Stage1/2 완전 학습 및 외부 검증 불가 |
| 10.3390/ijms21165851 | 공개 원문 확인. 표의 qe는 kinetic fitting 결과이며, 텍스트에는 그룹별 실험 qe 범위만 있어 시료별 실측 타깃 행으로 사용하지 않음. | 0 | BET 9개 수치 확인, TPV 없음 | Stage1 부분 참고, 목표 Stage2 불가 |
| 10.1016/j.fuel.2026.140665 | 출판사 및 Nottingham 저장소는 OA PDF를 표시하지만 현재 본문 PDF 가져오기는 403으로 실패. 초록/저장소 메타데이터만 확인. | 0 | BET/미세공극 관련 정보 언급, 미세공극부피는 TPV 대체 불가 | PDF 확보 후 재검토 |
| 10.1016/j.dwt.2025.101262 | 출판사 초록은 OA 논문이라고 표시하지만 본문 fetch는 403. 초록상 K400/K600/K800 및 별도 KOH 개질 K-K800, 평형 360분. | 0 | 시료별 값 미확인 | 원문 표가 있어야 재검토 |
| 10.3390/w12041117 | 공개 MDPI 본문에서 표 구분 확인. Table 2의 q_e는 동역학 모델 적합값, Table 3은 Langmuir Qm. | 0 | BET와 평균 공극직경; TPV 확인 안 됨 | 엄격 qe/TPV 부적격 |
| 10.1177/0734242X15615698 | PubMed 초록 및 SAGE 제한 접근 정보. 114.69 mg/g은 Langmuir로 추정한 최대 용량. | 0 | 초록에서는 시료별 BET/TPV 없음 | 원문 PDF/SI 필요 |

## 차나무 가지: 기존 5행 원문 대조

| Sample | 제조온도 | BET (m²/g) | 원문 pore volume (cm³/g) | qe 실제 (mg/g) | 판정 |
|---|---:|---:|---:|---:|---|
| TBB400 | 400°C | 5 | 0.05 | 37.043 | Strict qe verified; TPV 정의 보류 |
| TBB500 | 500°C | 8 | 0.07 | 37.480 | Strict qe verified; TPV 정의 보류 |
| TBB600 | 600°C | 180 | 0.09 | 38.184 | Strict qe verified; TPV 정의 보류 |
| TBB700 | 700°C | 277 | 0.12 | 39.218 | Strict qe verified; TPV 정의 보류 |
| TBB800 | 800°C | 208 | 0.11 | 33.657 | Strict qe verified; TPV 정의 보류 |

제조는 N₂ 60 mL/min, 승온속도 10°C/min, 2시간 유지이며, 제조 후 1 M HCl로 deashing하고 중성까지 세척했습니다. 흡착조건은 Cd(II), C₀ 100 mg/L, 초기 pH 6, 0.05 g/25 mL(2 g/L), 25±0.5°C, 200 rpm, 24시간입니다. 논문 동역학 자료는 약 4시간 후 평형을 지지합니다. qe로부터 Ce를 역산하거나 측정 Ce로 기록하지 않았습니다. 질량수지 상한 C₀/Dose=50 mg/g 이하인 점은 점검했으나, 실제 Ce는 원문에서 확인되지 않았습니다.

논문 Table 1의 “pore volume” 값은 원문 보고값으로만 보존했습니다. Total pore volume이라고 명시적으로 검증되지 않았으므로 `TPV_verified=NR`이며, 목표 Stage 2 필수 특징으로 간주하지 않았습니다. Table 1의 C/H/N/O/ash는 바이오차의 조성이므로 열분해 전 원료 조성으로 옮기지 않았습니다.

## 기존 프로젝트 DOI 노출 대조

- 검색 가능한 프로젝트 파일에서 차나무 DOI는 v41 `BET_core.csv`/`BET_default_train_pool.csv`에 포함되어 있어 Stage 1 노출이 확인됩니다. v5 Stage 1 source candidate와 Stage 2 qe review/pore-definition review에도 기존 5개 관측이 있습니다. 따라서 신규 DOI도 신규 관측도 아니며 외부 holdout 불가입니다.
- 오렌지 DOI는 v5 `Paper_registry_26_DOI.csv`, `Source_Crosswalk.csv`, `QA_Review.csv`에 메타데이터/미검토 상태로 이미 기재되어 있습니다. 신규 후보로 계산하지 않았습니다.
- 나머지 네 DOI는 추출된 프로젝트의 텍스트 검색 대상에서 정확한 DOI 문자열이 발견되지 않았습니다. 이는 검색 가능한 파일 내 미발견을 뜻할 뿐, 전체 실험·모델 이력에서 노출되지 않았다는 독립성 증명은 아닙니다. 따라서 외부 holdout으로 승인하지 않았습니다.

## 후속 확보가 필요한 원문 자료

1. **Fuel 2026.140665**: University of Nottingham 저장소가 11.1 MB 저자 PDF를 목록에 두고 있습니다. 이 PDF와 SI를 Work에 첨부해 주세요. 특히 BET와 TPV가 별도 보고되는지, 흡착 데이터의 개별 실험값 및 Ce/C0/dose 조건을 확인해야 합니다. 공개 저장소의 PDF 링크: https://nottingham-repository.worktribe.com/output/68187072
2. **DWT 2025.101262**: 출판사에서 OA 논문으로 표시하지만 현 검토 채널의 본문 호출이 차단됐습니다. 본문 PDF와 SI를 첨부해 주세요. 반드시 K400/K600/K800와 K-K800을 구분하고, 그래프 실험점 및 최적 조건의 대응을 확인해야 합니다.
3. **Orange peel 2015**: SAGE 원문 PDF와 SI가 필요합니다. 초록의 114.69 mg/g Langmuir 최대값만으로 시료별 strict qe 행을 만들 수 없습니다.
4. **Poplar 2020**: 공개 본문 자체는 확인됐지만 실측 q(t)/등온선 원자료를 정확한 시료별 행으로 만들려면 그림 데이터 디지타이즈 또는 저자 공개 원자료가 필요합니다.
5. **IJMS 2020**: 공개 본문은 확보됐지만 BET는 표에 있고 TPV는 없으며, 시료별 empirical qe는 수치표가 아닌 kinetic plot에서 복구해야 합니다. 정밀한 신규 추출을 원하면 원본 그림/데이터 파일을 첨부하거나 digitization을 별도로 승인해야 합니다.

## 상태 카운트

| 항목 | 결과 |
|---|---:|
| 후보 DOI | 6 |
| DOI 정정 | 1 (jms → ijms) |
| 본문 또는 직접 원문 확인 | 3 (차, IJMS, poplar) |
| 공식 OA 원문 목록 확인했으나 본문 직접 접근 실패 | 2 (Fuel, DWT) |
| 제한 초록만 확인 | 1 (orange) |
| strict qe 검증 근거 확인 | 5개 기존 tea 관측 |
| 신규 데이터 행 | 0 |
| 신규 training-ready Stage 2 행 | 0 |
| 독립 외부 holdout DOI 확정 | 0 |
| 내부 동일조건 제조조건 비교계열 | 1 (tea/Cd/5 temperatures) |

## 1차 출처

- Tea branch: https://pmc.ncbi.nlm.nih.gov/articles/PMC9037675/ ; https://pubs.rsc.org/en/content/articlehtml/2021/ra/d1ra04235a
- IJMS sunflower/wood: https://www.mdpi.com/1422-0067/21/16/5851
- Fuel wood biochar: https://www.sciencedirect.com/science/article/pii/S0016236126024208 ; repository PDF record https://nottingham-repository.worktribe.com/output/68187072
- Spent coffee grounds: https://www.sciencedirect.com/science/article/pii/S1944398625002784
- Poplar/thiourea: https://www.mdpi.com/2073-4441/12/4/1117
- Orange peel: https://pubmed.ncbi.nlm.nih.gov/26608900/ ; https://doi.org/10.1177/0734242X15615698
