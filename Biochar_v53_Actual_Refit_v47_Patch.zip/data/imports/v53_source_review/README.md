# Biochar six DOI source review addendum

This package screens the six candidate papers in the user-provided image and records only source-supported observations. It does not alter the integrated project, active models, or prior approved data.

Files:
- `Six_DOI_Source_Screening.csv`: one row per DOI, access/exposure/eligibility review.
- `TeaBranch_Strict_qe_Review_Resolution.csv`: 5 existing tea-branch observations with empirical qe and separate feature/eligibility statuses.
- `Six_DOI_Observation_Approval_Ledger.csv`: approval count ledger; fitted/model capacities are not imported as strict qe.
- `Six_DOI_Review_Report.md`: narrative findings, limitations, next source requests.

A DOI absent from a searchable project text scan is not thereby certified as independent. A reported generic pore volume is not standardized to TPV without explicit source definition.
